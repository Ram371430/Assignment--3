# main.py
from gui import ImageEditorGUI

if __name__ == "__main__":
    app = ImageEditorGUI()
    app.run()
